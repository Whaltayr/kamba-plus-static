KAMBA+ sitemap files

Files included:
- sitemap.xml
- robots.txt

Current base URL:
https://www.kambamais.com

If the real domain is different, replace it in:
- sitemap.xml
- robots.txt

Upload both files to the root of the website, next to index.html.

Recommended structure:
/
  index.html
  services.html
  projects.html
  about.html
  contact.html
  sitemap.xml
  robots.txt
